package com.example.mitgliederList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MitgliederListApplication {

	public static void main(String[] args) {
		SpringApplication.run(MitgliederListApplication.class, args);
	}

}
